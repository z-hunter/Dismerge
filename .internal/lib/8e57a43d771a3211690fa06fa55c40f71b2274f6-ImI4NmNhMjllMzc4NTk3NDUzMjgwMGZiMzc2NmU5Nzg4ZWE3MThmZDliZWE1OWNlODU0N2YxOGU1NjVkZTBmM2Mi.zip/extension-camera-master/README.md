# Camera extension for Defold

Defold [native extension](https://www.defold.com/manuals/extensions/) which provides access to the camera on macOS, iOS and Android.

[Manual, API and setup instructions](https://www.defold.com/extension-camera/) is available on the official Defold site.
